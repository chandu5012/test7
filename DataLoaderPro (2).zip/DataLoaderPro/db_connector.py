"""
DBConnector — zero hardcoded values.

Every connection parameter is supplied by the user at runtime:
  - jdbc_url      : full JDBC URL (built by the UI, user can edit freely)
  - driver_class  : Java class name of the JDBC driver
  - jar_name      : JAR filename (or full path); if just a filename, looked up
                    in the  jdbc/  subfolder next to this script
  - username      : DB username
  - password      : DB password
  - db_type       : 'sqlserver' | 'oracle' | 'teradata'  (for metadata queries)
  - host/port/db  : passed through in case jdbc_url is empty and a URL must be built

The backend never injects connection properties on its own.
"""

import os
from typing import Any, Dict, List, Tuple

# jdbc/ folder sitting next to this script
JDBC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "jdbc")


class DBConnector:

    def __init__(self, db_type: str, config: dict):
        """
        config keys (all user-supplied from the UI):
          jdbc_url, driver_class, jar_name,
          username, password,
          host, port, database,
          extra_props  (list of {key, value})
        """
        self.db_type = (db_type or "").lower().replace(" ", "").replace("_", "")
        self.config  = config or {}
        self._mock_mode   = False
        self._mock_reason = ""

    # ── Public API ────────────────────────────────────────────── #

    def test_connection(self) -> Dict[str, Any]:
        try:
            conn = self._get_connection()
            if conn == "mock":
                return {"success": True, "mock": True, "reason": self._mock_reason}
            conn.close()
            return {"success": True, "mock": False}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_table_metadata(self, table_name: str) -> List[Dict[str, str]]:
        if self._mock_mode:
            return self._mock_metadata(table_name)
        try:
            conn = self._get_connection()
            if conn == "mock":
                return self._mock_metadata(table_name)
            cur = conn.cursor()
            cur.execute(self._metadata_query(table_name))
            rows = cur.fetchall()
            cur.close(); conn.close()
            return [{"name": str(r[0]), "data_type": str(r[1])} for r in rows]
        except Exception:
            self._mock_mode = True
            return self._mock_metadata(table_name)

    def execute_insert(self, table_name: str, columns: List[str], rows: List[List[Any]]) -> int:
        if self._mock_mode:
            return len(rows)
        try:
            conn = self._get_connection()
            if conn == "mock":
                return len(rows)
            cur = conn.cursor()
            ph  = ", ".join(["?" for _ in columns])
            sql = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({ph})"
            cur.executemany(sql, rows)
            conn.commit()
            count = cur.rowcount if cur.rowcount >= 0 else len(rows)
            cur.close(); conn.close()
            return count
        except Exception:
            self._mock_mode = True
            raise

    # ── Connection ────────────────────────────────────────────── #

    def _get_connection(self):
        """
        Build and return a live JDBC connection, or the sentinel 'mock'.
        Uses only what the user provided — nothing is injected here.
        """
        # 1. JayDeBeApi must be installed
        try:
            import jaydebeapi
        except ImportError:
            self._mock_mode   = True
            self._mock_reason = (
                "jaydebeapi is not installed. "
                "Run:  pip install jaydebeapi JPype1"
            )
            return "mock"

        # 2. Resolve the JAR path
        jar_path = self._resolve_jar()
        if not jar_path:
            return "mock"           # _mock_reason already set

        # 3. Driver class — must be provided by the user
        driver_class = self.config.get("driver_class", "").strip()
        if not driver_class:
            self._mock_mode   = True
            self._mock_reason = "JDBC driver class is empty. Please fill in the 'JDBC Driver Class' field."
            return "mock"

        # 4. JDBC URL — use the one the user typed; if blank, try to build from parts
        jdbc_url = self.config.get("jdbc_url", "").strip()
        if not jdbc_url:
            jdbc_url = self._build_fallback_url()
        if not jdbc_url:
            self._mock_mode   = True
            self._mock_reason = "JDBC URL is empty. Please fill in the connection fields."
            return "mock"

        # 5. Credentials
        username = self.config.get("username", "")
        password = self.config.get("password", "")

        # 6. Connect — pass credentials as positional args; URL already has any extra props
        conn = jaydebeapi.connect(
            driver_class,
            jdbc_url,
            [username, password],
            jar_path,
        )
        return conn

    def _resolve_jar(self) -> str | None:
        """
        Resolve the JAR to an absolute path.
        Accepts:
          - absolute path   → used as-is if it exists
          - bare filename   → looked up in JDBC_DIR
          - prefix/glob     → first match in JDBC_DIR whose name starts with the value
        Returns None (with _mock_reason set) when nothing found.
        """
        raw = self.config.get("jar_name", "").strip()

        # If user provided an absolute path that exists → use it
        if raw and os.path.isabs(raw) and os.path.isfile(raw):
            return raw

        # If it's a relative path that exists relative to JDBC_DIR → use it
        if raw:
            candidate = os.path.join(JDBC_DIR, raw)
            if os.path.isfile(candidate):
                return candidate

            # Fuzzy: any file in JDBC_DIR whose lower-case name contains the raw value
            raw_lower = raw.lower().rstrip(".jar").rstrip("*")
            if os.path.isdir(JDBC_DIR):
                for fname in os.listdir(JDBC_DIR):
                    if raw_lower in fname.lower():
                        return os.path.join(JDBC_DIR, fname)

            # Nothing found — give a clear message
            files_present = os.listdir(JDBC_DIR) if os.path.isdir(JDBC_DIR) else ["(jdbc\\ folder missing)"]
            self._mock_mode   = True
            self._mock_reason = (
                f"JAR '{raw}' not found. "
                f"jdbc\\ folder contains: {files_present}. "
                f"Make sure the JAR filename in the UI matches a file in the jdbc\\ folder."
            )
            return None

        # No jar_name given at all → scan JDBC_DIR for anything matching db_type keywords
        fallback_keywords = {
            "sqlserver": ["mssql", "sqlserver", "jtds"],
            "oracle":    ["ojdbc", "oracle"],
            "teradata":  ["terajdbc", "teradata"],
        }.get(self.db_type, [])

        if os.path.isdir(JDBC_DIR) and fallback_keywords:
            for fname in os.listdir(JDBC_DIR):
                if any(kw in fname.lower() for kw in fallback_keywords):
                    return os.path.join(JDBC_DIR, fname)

        files_present = os.listdir(JDBC_DIR) if os.path.isdir(JDBC_DIR) else ["(folder missing)"]
        self._mock_mode   = True
        self._mock_reason = (
            f"No JDBC JAR specified and none found in jdbc\\ folder for db_type='{self.db_type}'. "
            f"Files present: {files_present}. "
            f"Enter the JAR filename in the 'JDBC JAR Filename' field on the connection form."
        )
        return None

    def _build_fallback_url(self) -> str:
        """
        Last-resort URL builder from individual fields.
        Only called when the user left the JDBC URL field blank.
        """
        h   = self.config.get("host", "").strip()
        p   = str(self.config.get("port", "")).strip()
        db  = self.config.get("database", "").strip()
        ex  = self.config.get("extra_props", [])  # [{key,value}]

        extra = ";" + ";".join(f"{e['key']}={e['value']}" for e in ex if e.get("key")) if ex else ""

        if self.db_type == "sqlserver":
            port_part = f":{p}" if p and "\\" not in h else ""
            return f"jdbc:sqlserver://{h}{port_part};databaseName={db}{extra}"
        elif self.db_type == "oracle":
            return f"jdbc:oracle:thin:@{h}:{p}/{db}{extra}"
        elif self.db_type == "teradata":
            return f"jdbc:teradata://{h}/DATABASE={db}{extra}"
        return ""

    # ── Metadata queries ──────────────────────────────────────── #

    def _metadata_query(self, table_name: str) -> str:
        schema, tbl = self._split_table(table_name)
        if self.db_type == "sqlserver":
            where = f"AND TABLE_SCHEMA = '{schema}'" if schema else ""
            return (f"SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS "
                    f"WHERE TABLE_NAME = '{tbl}' {where} ORDER BY ORDINAL_POSITION")
        elif self.db_type == "oracle":
            owner = schema.upper() if schema else self.config.get("username", "").upper()
            return (f"SELECT COLUMN_NAME, DATA_TYPE FROM ALL_TAB_COLUMNS "
                    f"WHERE TABLE_NAME = '{tbl.upper()}' AND OWNER = '{owner}' ORDER BY COLUMN_ID")
        elif self.db_type == "teradata":
            db = schema if schema else self.config.get("database", "")
            return (f"SELECT ColumnName, ColumnType FROM DBC.Columns "
                    f"WHERE DatabaseName = '{db}' AND TableName = '{tbl}'")
        raise ValueError(f"Unknown db_type: {self.db_type}")

    def _split_table(self, table_name: str):
        parts = table_name.split(".", 1)
        return (parts[0], parts[1]) if len(parts) == 2 else (None, parts[0])

    def _mock_metadata(self, table_name: str) -> List[Dict[str, str]]:
        return [
            {"name": "ID",            "data_type": "INTEGER"},
            {"name": "NAME",          "data_type": "VARCHAR"},
            {"name": "EMAIL",         "data_type": "VARCHAR"},
            {"name": "CREATED_DATE",  "data_type": "DATE"},
            {"name": "STATUS",        "data_type": "VARCHAR"},
            {"name": "AMOUNT",        "data_type": "DECIMAL"},
            {"name": "DESCRIPTION",   "data_type": "VARCHAR"},
            {"name": "MODIFIED_DATE", "data_type": "TIMESTAMP"},
        ]
