"""
Reads Excel (.xlsx/.xls) and CSV files, extracts sheet metadata and data.
"""

import io
from typing import List, Dict, Any

import pandas as pd


class FileProcessor:
    """Parse uploaded files and return metadata + dataframes."""

    def extract_metadata(self, content: bytes, filename: str) -> List[Dict[str, Any]]:
        """Return list of sheet info: {name, row_count, columns: [{name, inferred_type}]}"""
        ext = filename.lower().rsplit(".", 1)[-1]

        if ext == "csv":
            return self._csv_metadata(content)
        elif ext in ("xlsx", "xls"):
            return self._excel_metadata(content)
        else:
            raise ValueError(f"Unsupported file extension: .{ext}")

    def read_sheet(self, content: bytes, filename: str, sheet_name: str) -> pd.DataFrame:
        """Read a specific sheet/csv into a DataFrame."""
        ext = filename.lower().rsplit(".", 1)[-1]

        if ext == "csv":
            df = pd.read_csv(io.BytesIO(content), dtype=str)
        else:
            df = pd.read_excel(io.BytesIO(content), sheet_name=sheet_name, dtype=str)

        # Clean column names
        df.columns = [str(c).strip() for c in df.columns]
        # Drop fully empty rows
        df = df.dropna(how="all")
        return df

    # ------------------------------------------------------------------ #

    def _csv_metadata(self, content: bytes) -> List[Dict[str, Any]]:
        df = pd.read_csv(io.BytesIO(content))
        return [
            {
                "name": "Sheet1",
                "row_count": len(df),
                "columns": self._col_meta(df),
            }
        ]

    def _excel_metadata(self, content: bytes) -> List[Dict[str, Any]]:
        xl = pd.ExcelFile(io.BytesIO(content))
        result = []
        for sheet in xl.sheet_names:
            df = xl.parse(sheet)
            result.append(
                {
                    "name": str(sheet),
                    "row_count": len(df),
                    "columns": self._col_meta(df),
                }
            )
        return result

    def _col_meta(self, df: pd.DataFrame) -> List[Dict[str, str]]:
        mapping = {
            "int64": "INTEGER",
            "float64": "DECIMAL",
            "bool": "BOOLEAN",
            "datetime64[ns]": "TIMESTAMP",
            "object": "VARCHAR",
        }
        cols = []
        for col in df.columns:
            dtype = str(df[col].dtype)
            db_type = mapping.get(dtype, "VARCHAR")
            cols.append({"name": str(col), "inferred_type": db_type})
        return cols
