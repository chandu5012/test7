Place your JDBC driver JAR file(s) in this folder.

──────────────────────────────────────────────────
 DATABASE       JAR FILE (any version is fine)
──────────────────────────────────────────────────
 SQL Server   → mssql-jdbc-*.jar
               e.g. mssql-jdbc-12.8.1.jre8

 Oracle       → ojdbc*.jar
               e.g. ojdbc8.jar  or  ojdbc11.jar

 Teradata     → terajdbc*.jar
               e.g. terajdbc4.jar

──────────────────────────────────────────────────
Download links:
  SQL Server : https://aka.ms/downloadmssqljdbc
  Oracle     : https://www.oracle.com/database/technologies/appdev/jdbc-downloads.html
  Teradata   : https://downloads.teradata.com/download/connectivity/jdbc-driver

After placing the JAR here, run run.bat again.
The app will auto-detect it by name.
