@echo off
setlocal EnableDelayedExpansion

title DataLoader Pro — Startup

echo.
echo  =========================================================
echo   ^|^|  DataLoader Pro  v1.2
echo   ^|_^|  Excel / CSV  -^>  SQL Server / Oracle / Teradata
echo  =========================================================
echo.

:: ════════════════════════════════════════════════════════
::  STEP 0 — Kill any process already using port 8000
:: ════════════════════════════════════════════════════════
echo  [0/4] Checking for existing processes on port 8000...

:: Find PID listening on TCP port 8000
set OLD_PID=
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /R ":8000 " ^| findstr "LISTENING"') do (
    set OLD_PID=%%p
)

if defined OLD_PID (
    echo  [KILL] Found process PID !OLD_PID! using port 8000. Terminating...
    taskkill /PID !OLD_PID! /F >nul 2>&1
    if errorlevel 1 (
        echo  [WARN] Could not kill PID !OLD_PID! — try running as Administrator.
    ) else (
        echo  [OK] Killed PID !OLD_PID!
    )
    :: Wait a moment for port to be released
    timeout /t 2 /nobreak >nul
) else (
    echo  [OK] Port 8000 is free
)

:: Also kill any leftover python processes running main.py
echo  [KILL] Checking for leftover main.py python processes...
taskkill /FI "IMAGENAME eq python.exe" /FI "WINDOWTITLE eq DataLoader*" /F >nul 2>&1
for /f "tokens=2" %%p in ('wmic process where "name='python.exe' and commandline like '%%main.py%%'" get processid 2^>nul ^| findstr /R "[0-9]"') do (
    echo  [KILL] Killing leftover python main.py PID %%p
    taskkill /PID %%p /F >nul 2>&1
)
timeout /t 1 /nobreak >nul

:: ════════════════════════════════════════════════════════
::  STEP 1 — Check Python
:: ════════════════════════════════════════════════════════
echo.
echo  [1/4] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python not found in PATH.
    echo  Install Python 3.9+ from https://www.python.org/downloads/
    echo  Make sure to tick "Add Python to PATH" during install.
    echo.
    pause & exit /b 1
)
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PY_VER=%%v
echo  [OK] Python %PY_VER%

:: ════════════════════════════════════════════════════════
::  STEP 2 — Check Java
:: ════════════════════════════════════════════════════════
echo.
echo  [2/4] Checking Java (required for real DB connections)...
java -version >nul 2>&1
if errorlevel 1 (
    echo  [WARN] Java not found. JDBC connections will NOT work.
    echo         Download Java 8+ from https://adoptium.net
    echo         App will still run in demo mode without Java.
) else (
    echo  [OK] Java is installed
)

:: ════════════════════════════════════════════════════════
::  STEP 3 — Install Python packages
:: ════════════════════════════════════════════════════════
echo.
echo  [3/4] Installing / verifying Python packages...
pip install ^
    fastapi==0.109.2 ^
    "uvicorn[standard]==0.27.1" ^
    python-multipart==0.0.9 ^
    pandas==2.1.4 ^
    openpyxl==3.1.2 ^
    xlrd==2.0.1 ^
    jaydebeapi ^
    JPype1 ^
    --quiet --no-warn-script-location

if errorlevel 1 (
    echo  [WARN] Some packages may have failed. Retrying core packages...
    pip install fastapi "uvicorn[standard]" python-multipart pandas openpyxl xlrd --quiet
)
echo  [OK] Packages ready

:: ════════════════════════════════════════════════════════
::  JDBC jar status
:: ════════════════════════════════════════════════════════
echo.
echo  ─────────────────────────────────────────────────────────
echo   JDBC Driver Status
echo  ─────────────────────────────────────────────────────────

set JDBC_FOUND=0
if exist "%~dp0jdbc\*mssql*"    ( echo  [OK] SQL Server JAR found  & set JDBC_FOUND=1 ) else ( echo  [--] SQL Server : no jar ^(need mssql-jdbc-*.jar in jdbc\^) )
if exist "%~dp0jdbc\*ojdbc*"    ( echo  [OK] Oracle JAR found       & set JDBC_FOUND=1 ) else ( echo  [--] Oracle     : no jar ^(need ojdbc*.jar in jdbc\^) )
if exist "%~dp0jdbc\*teradata*" ( echo  [OK] Teradata JAR found     & set JDBC_FOUND=1 ) else ( echo  [--] Teradata   : no jar ^(need terajdbc*.jar in jdbc\^) )
if exist "%~dp0jdbc\*jtds*"     ( echo  [OK] jTDS SQL Server JAR found & set JDBC_FOUND=1 )

if %JDBC_FOUND%==0 (
    echo.
    echo  [INFO] No JDBC jars found — running in DEMO MODE.
    echo         Place your driver JAR in the jdbc\ folder to connect to a real DB.
)
echo  ─────────────────────────────────────────────────────────

:: ════════════════════════════════════════════════════════
::  STEP 4 — Launch server
:: ════════════════════════════════════════════════════════
echo.
echo  [4/4] Starting DataLoader Pro...
echo.
echo  =========================================================
echo   Browser : http://localhost:8000
echo   Stop    : Ctrl+C  (or close this window)
echo  =========================================================
echo.

cd /d "%~dp0"

:: Open browser with hard-refresh after 3s (Ctrl+Shift+R equivalent via URL cache-bust)
start "" cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:8000"

python main.py

echo.
echo  Server stopped.
pause
endlocal
