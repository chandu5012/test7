"""
Thread-safe in-memory log manager for SSE streaming.
"""

import threading
from datetime import datetime
from typing import List, Dict, Any


class LogManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._logs: Dict[str, List[dict]] = {}
        self._closed: set = set()

    def init_job(self, job_id: str):
        with self._lock:
            self._logs[job_id] = []
            self._closed.discard(job_id)

    def log(self, job_id: str, level: str, message: str):
        entry = {
            "type": "log",
            "level": level,
            "message": message,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
        }
        with self._lock:
            if job_id not in self._logs:
                self._logs[job_id] = []
            self._logs[job_id].append(entry)

    def get_logs(self, job_id: str, from_index: int) -> List[dict]:
        with self._lock:
            logs = self._logs.get(job_id, [])
            return logs[from_index:]

    def log_count(self, job_id: str) -> int:
        with self._lock:
            return len(self._logs.get(job_id, []))

    def close_job(self, job_id: str):
        with self._lock:
            self._closed.add(job_id)

    def is_closed(self, job_id: str) -> bool:
        return job_id in self._closed
