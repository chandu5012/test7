import asyncio
import json
import os
import time
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any
import io

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from db_connector import DBConnector
from file_processor import FileProcessor
from schema_comparator import SchemaComparator
from data_loader import DataLoader
from log_manager import LogManager

# Resolve paths relative to this file so the app works from any CWD
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = FastAPI(title="DataLoader Pro", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

sessions: Dict[str, dict] = {}
log_manager = LogManager()
active_jobs: Dict[str, dict] = {}


@app.get("/")
async def root():
    return FileResponse(os.path.join(BASE_DIR, "index.html"))


@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    session_id = str(uuid.uuid4())
    if not file.filename.endswith(('.xlsx', '.xls', '.csv')):
        raise HTTPException(400, "Only .xlsx, .xls, .csv files are supported")
    content = await file.read()
    processor = FileProcessor()
    try:
        sheets_meta = processor.extract_metadata(content, file.filename)
    except Exception as e:
        raise HTTPException(400, f"Failed to parse file: {str(e)}")
    sessions[session_id] = {
        "filename": file.filename,
        "file_content": content,
        "sheets_meta": sheets_meta,
        "db_config": None,
        "mappings": {},
        "skipped_tables": [],
    }
    return {"session_id": session_id, "filename": file.filename, "sheets": sheets_meta}


@app.post("/api/validate-connection")
async def validate_connection(body: dict):
    # body IS the full user-supplied config — pass it straight to DBConnector
    db_type = body.get("db_type")
    connector = DBConnector(db_type, body)
    result = connector.test_connection()
    if not result["success"]:
        raise HTTPException(400, result["error"])
    return {
        "success": True,
        "message": "Connection successful",
        "mock": result.get("mock", False),
        "mock_reason": result.get("reason", ""),
    }


@app.post("/api/fetch-table-metadata")
async def fetch_table_metadata(body: dict):
    session_id = body.get("session_id")
    db_type    = body.get("db_type")
    tables     = body.get("tables", [])
    if session_id not in sessions:
        raise HTTPException(404, "Session not found")
    # Store full user config (includes jdbc_url, driver_class, jar_name, etc.)
    sessions[session_id]["db_config"] = body
    connector = DBConnector(db_type, body)
    result = {}
    for table in tables:
        try:
            columns = connector.get_table_metadata(table)
            result[table] = {"success": True, "columns": columns}
        except Exception as e:
            result[table] = {"success": False, "error": str(e)}
    return {"tables": result}


@app.post("/api/compare-schema")
async def compare_schema(body: dict):
    session_id = body.get("session_id")
    sheet_name = body.get("sheet_name")
    db_columns = body.get("db_columns", [])
    if session_id not in sessions:
        raise HTTPException(404, "Session not found")
    session = sessions[session_id]
    sheet_meta = next((s for s in session["sheets_meta"] if s["name"] == sheet_name), None)
    if not sheet_meta:
        raise HTTPException(404, f"Sheet '{sheet_name}' not found")
    comparator = SchemaComparator()
    return comparator.compare(sheet_meta["columns"], db_columns)


@app.post("/api/save-mapping")
async def save_mapping(body: dict):
    session_id = body.get("session_id")
    sheet_name = body.get("sheet_name")
    table_name = body.get("table_name")
    mapping = body.get("mapping", {})
    if session_id not in sessions:
        raise HTTPException(404, "Session not found")
    sessions[session_id]["mappings"][sheet_name] = {"table_name": table_name, "column_mapping": mapping}
    return {"success": True}


@app.post("/api/skip-table")
async def skip_table(body: dict):
    session_id = body.get("session_id")
    sheet_name = body.get("sheet_name")
    skip = body.get("skip", True)
    if session_id not in sessions:
        raise HTTPException(404, "Session not found")
    skipped = sessions[session_id]["skipped_tables"]
    if skip and sheet_name not in skipped:
        skipped.append(sheet_name)
    elif not skip and sheet_name in skipped:
        skipped.remove(sheet_name)
    return {"success": True, "skipped_tables": skipped}


@app.post("/api/start-job")
async def start_job(body: dict, background_tasks: BackgroundTasks):
    session_id = body.get("session_id")
    if session_id not in sessions:
        raise HTTPException(404, "Session not found")
    job_id = str(uuid.uuid4())
    active_jobs[job_id] = {
        "session_id": session_id,
        "status": "running",
        "started_at": datetime.now().isoformat(),
        "progress": 0,
        "results": [],
    }
    log_manager.init_job(job_id)
    background_tasks.add_task(run_loading_job, job_id, sessions[session_id])
    return {"job_id": job_id}


async def run_loading_job(job_id: str, session: dict):
    db_cfg = session.get("db_config", {})
    mappings = session.get("mappings", {})
    skipped = session.get("skipped_tables", [])
    file_content = session.get("file_content")
    filename = session.get("filename")
    sheets_meta = session.get("sheets_meta", [])

    job = active_jobs[job_id]
    total_sheets = len([s for s in sheets_meta if s["name"] not in skipped])
    processed = 0

    log_manager.log(job_id, "INFO", f"Job started. Processing {total_sheets} sheet(s)")
    log_manager.log(job_id, "INFO", f"Database: {db_cfg.get('db_type', 'N/A')}")

    start_time = time.time()
    processor = FileProcessor()
    connector = DBConnector(db_cfg.get("db_type"), db_cfg)  # full user config
    loader = DataLoader(connector, log_manager, job_id)

    for sheet in sheets_meta:
        sheet_name = sheet["name"]
        if sheet_name in skipped:
            log_manager.log(job_id, "WARN", f"Skipping sheet: {sheet_name}")
            continue
        mapping_info = mappings.get(sheet_name)
        if not mapping_info:
            log_manager.log(job_id, "WARN", f"No mapping for sheet '{sheet_name}', skipping")
            continue
        table_name = mapping_info["table_name"]
        column_mapping = mapping_info["column_mapping"]
        log_manager.log(job_id, "INFO", f"Processing sheet: '{sheet_name}' -> table: '{table_name}'")
        try:
            df = processor.read_sheet(file_content, filename, sheet_name)
            log_manager.log(job_id, "INFO", f"   Rows read: {len(df)}")
            success, rows_loaded, error = await loader.load_data(df, table_name, column_mapping)
            if success:
                log_manager.log(job_id, "SUCCESS", f"'{table_name}' loaded successfully - {rows_loaded} rows inserted")
                job["results"].append({"sheet": sheet_name, "table": table_name, "status": "success", "rows": rows_loaded})
            else:
                log_manager.log(job_id, "ERROR", f"Failed to load '{table_name}': {error}")
                job["results"].append({"sheet": sheet_name, "table": table_name, "status": "failed", "error": error})
        except Exception as e:
            log_manager.log(job_id, "ERROR", f"Exception on '{sheet_name}': {str(e)}")
            job["results"].append({"sheet": sheet_name, "table": table_name, "status": "failed", "error": str(e)})
        processed += 1
        job["progress"] = int((processed / total_sheets) * 100)

    elapsed = round(time.time() - start_time, 2)
    success_count = len([r for r in job["results"] if r["status"] == "success"])
    fail_count = len([r for r in job["results"] if r["status"] == "failed"])
    log_manager.log(job_id, "INFO", "")
    log_manager.log(job_id, "INFO", "=" * 50)
    log_manager.log(job_id, "SUCCESS" if fail_count == 0 else "WARN",
                    f"Job complete in {elapsed}s | Success: {success_count} | Failed: {fail_count}")
    job["status"] = "complete" if fail_count == 0 else "partial"
    job["progress"] = 100
    job["elapsed"] = elapsed
    log_manager.close_job(job_id)


@app.get("/api/job-status/{job_id}")
async def job_status(job_id: str):
    if job_id not in active_jobs:
        raise HTTPException(404, "Job not found")
    job = active_jobs[job_id].copy()
    job.pop("session_id", None)
    return job


@app.get("/api/stream-logs/{job_id}")
async def stream_logs(job_id: str):
    async def event_generator():
        last_index = 0
        while True:
            logs = log_manager.get_logs(job_id, last_index)
            for log in logs:
                yield f"data: {json.dumps(log)}\n\n"
                last_index += 1
            job = active_jobs.get(job_id, {})
            if job.get("status") in ("complete", "partial", "failed"):
                if last_index >= log_manager.log_count(job_id):
                    yield f"data: {json.dumps({'type': 'done', 'progress': 100})}\n\n"
                    break
            await asyncio.sleep(0.3)
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/download-report/{job_id}")
async def download_report(job_id: str):
    if job_id not in active_jobs:
        raise HTTPException(404, "Job not found")
    job = active_jobs[job_id]
    logs = log_manager.get_logs(job_id, 0)
    report = {
        "job_id": job_id,
        "started_at": job.get("started_at"),
        "elapsed_seconds": job.get("elapsed"),
        "status": job.get("status"),
        "results": job.get("results", []),
        "logs": [f"[{l['level']}] {l['message']}" for l in logs],
    }
    content = json.dumps(report, indent=2)
    return StreamingResponse(
        io.BytesIO(content.encode()),
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename=report_{job_id[:8]}.json"},
    )


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
