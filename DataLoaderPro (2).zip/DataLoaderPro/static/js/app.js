/* ═══════════════════════════════════════════════════════════════
   DataLoader Pro — App Script
   All JDBC parameters are user-supplied — nothing is hardcoded.
═══════════════════════════════════════════════════════════════ */

const API = '';

// ─── State ────────────────────────────────────────────────────
const state = {
  sessionId: null,
  filename: null,
  sheets: [],
  dbType: 'sqlserver',
  connConfig: {},
  sheetTableMap: {},
  skippedSheets: new Set(),
  dbTableMeta: {},
  schemaComparisons: {},
  columnMappings: {},
  jobId: null,
  timerInterval: null,
  elapsedSec: 0,
};

// ─── Per-DB defaults shown in fields (all user-editable) ──────
const DB_DEFAULTS = {
  sqlserver: {
    port:        '1433',
    dbLabel:     'Database Name',
    dbPlaceholder:'e.g. MyDatabase',
    driverClass: 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
    jarHint:     'mssql-jdbc-*.jar  (place in jdbc\\ folder)',
    jarKeyword:  'mssql',
    urlTemplate: (h, p, db) => {
      const portPart = p ? `:${p}` : '';
      const hasInstance = h.includes('\\') || h.includes('/');
      if (hasInstance && !p) {
        return `jdbc:sqlserver://${h};databaseName=${db}`;
      }
      return `jdbc:sqlserver://${h}${portPart};databaseName=${db}`;
    },
    extraProps: [
      { key: 'encrypt',                  value: 'false' },
      { key: 'trustServerCertificate',   value: 'true'  },
      { key: 'integratedSecurity',       value: 'false' },
    ],
  },
  oracle: {
    port:        '1521',
    dbLabel:     'Service Name',
    dbPlaceholder:'e.g. ORCL  or  orclpdb1',
    driverClass: 'oracle.jdbc.OracleDriver',
    jarHint:     'ojdbc8.jar or ojdbc11.jar  (place in jdbc\\ folder)',
    jarKeyword:  'ojdbc',
    urlTemplate: (h, p, db) =>
      `jdbc:oracle:thin:@${h}:${p || '1521'}/${db}`,
    extraProps: [],
  },
  teradata: {
    port:        '1025',
    dbLabel:     'Database Name',
    dbPlaceholder:'e.g. MyTDDatabase',
    driverClass: 'com.teradata.jdbc.TeraDriver',
    jarHint:     'terajdbc4.jar  (place in jdbc\\ folder)',
    jarKeyword:  'terajdbc',
    urlTemplate: (h, p, db) =>
      `jdbc:teradata://${h}/DATABASE=${db}`,
    extraProps: [
      { key: 'TMODE', value: 'ANSI' },
      { key: 'CHARSET', value: 'UTF8' },
    ],
  },
};

// ─── Extra-props row counter ───────────────────────────────────
let propRowId = 0;

// ═══════════════════════════════════════════════════════════════
//  INIT
// ═══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  initUpload();
  initDBSelector();
  initNavigation();
  switchDB('sqlserver');  // populate defaults on load
});

// ═══════════════════════════════════════════════════════════════
//  STEP 1 — UPLOAD
// ═══════════════════════════════════════════════════════════════
function initUpload() {
  const zone     = document.getElementById('upload-zone');
  const input    = document.getElementById('file-input');
  const browseBtn = document.getElementById('browse-btn');

  browseBtn.addEventListener('click', () => input.click());
  zone.addEventListener('click', e => { if (e.target !== browseBtn) input.click(); });
  zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('drag-over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', e => {
    e.preventDefault(); zone.classList.remove('drag-over');
    if (e.dataTransfer.files[0]) handleFileSelect(e.dataTransfer.files[0]);
  });
  input.addEventListener('change', () => { if (input.files[0]) handleFileSelect(input.files[0]); });
}

async function handleFileSelect(file) {
  const ext = '.' + file.name.split('.').pop().toLowerCase();
  if (!['.xlsx', '.xls', '.csv'].includes(ext)) {
    showToast('error', `Unsupported file type: ${ext}`);
    return;
  }
  showToast('info', `Uploading ${file.name}…`);
  const form = new FormData();
  form.append('file', file);
  try {
    const res  = await fetch(`${API}/api/upload`, { method: 'POST', body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Upload failed');
    state.sessionId = data.session_id;
    state.filename  = data.filename;
    state.sheets    = data.sheets;
    renderUploadPreview(data);
    document.getElementById('btn-upload-next').disabled = false;
    showToast('success', `Uploaded: ${file.name}`);
  } catch (err) { showToast('error', err.message); }
}

function renderUploadPreview(data) {
  document.getElementById('preview-filename').textContent = data.filename;
  const isExcel = /\.(xlsx|xls)$/i.test(data.filename);
  const badge = document.getElementById('preview-badge');
  badge.textContent = isExcel ? `${data.sheets.length} sheet(s)` : 'CSV';
  badge.className = 'badge badge-blue';
  document.getElementById('sheets-list').innerHTML = data.sheets.map(s => `
    <div class="sheet-chip">
      📄 ${esc(s.name)}
      <span class="chip-count">${s.row_count.toLocaleString()} rows · ${s.columns.length} cols</span>
    </div>`).join('');
  document.getElementById('upload-preview').classList.remove('hidden');
}

// ═══════════════════════════════════════════════════════════════
//  STEP 2 — DB CONNECTION  (fully user-configurable)
// ═══════════════════════════════════════════════════════════════
function initDBSelector() {
  document.querySelectorAll('.db-btn').forEach(btn => {
    btn.addEventListener('click', () => switchDB(btn.dataset.db));
  });

  // Rebuild URL whenever basic fields change
  ['conn-host', 'conn-port', 'conn-database'].forEach(id => {
    document.getElementById(id).addEventListener('input', rebuildUrl);
  });

  // Manual URL edits are kept as-is (no auto-rebuild on blur)
  document.getElementById('btn-rebuild-url').addEventListener('click', rebuildUrl);

  // Add property row button
  document.getElementById('btn-add-prop').addEventListener('click', () => addPropRow('', ''));
}

function switchDB(dbType) {
  state.dbType = dbType;
  document.querySelectorAll('.db-btn').forEach(b => b.classList.toggle('active', b.dataset.db === dbType));

  const def = DB_DEFAULTS[dbType];

  // Port
  const portEl = document.getElementById('conn-port');
  portEl.value = portEl.value || def.port;
  portEl.placeholder = def.port;

  // DB label + placeholder
  document.getElementById('db-label').textContent = def.dbLabel;
  document.getElementById('conn-database').placeholder = def.dbPlaceholder;

  // Driver class
  document.getElementById('conn-driver-class').value = def.driverClass;

  // JAR hint
  document.getElementById('jar-hint').textContent = '📁 ' + def.jarHint;

  // Reset extra props to DB defaults (only if user hasn't touched them)
  const list = document.getElementById('extra-props-list');
  if (list.children.length === 0) {
    def.extraProps.forEach(p => addPropRow(p.key, p.value));
  }

  rebuildUrl();
  updateAdvBadge();
}

function rebuildUrl() {
  const h  = v('conn-host').trim();
  const p  = v('conn-port').trim();
  const db = v('conn-database').trim();
  if (!h && !db) return;
  const def = DB_DEFAULTS[state.dbType];
  let url = def.urlTemplate(h || 'HOST', p, db || 'DATABASE');

  // Append extra props as semicolon params
  const props = collectExtraProps();
  if (props.length) {
    url += ';' + props.map(kv => `${kv.key}=${kv.value}`).join(';');
  }

  document.getElementById('conn-jdbc-url').value = url;
}

function addPropRow(key, value) {
  const id = ++propRowId;
  const row = document.createElement('div');
  row.className = 'prop-row';
  row.id = `prop-row-${id}`;
  row.innerHTML = `
    <input class="form-input mono prop-key"   type="text" placeholder="key"   value="${esc(key)}" />
    <input class="form-input mono prop-value" type="text" placeholder="value" value="${esc(value)}" />
    <button class="btn-del-prop" onclick="removePropRow(${id})" title="Remove">✕</button>
  `;
  // Rebuild URL on change
  row.querySelectorAll('input').forEach(inp => inp.addEventListener('input', () => { rebuildUrl(); updateAdvBadge(); }));
  document.getElementById('extra-props-list').appendChild(row);
  updateAdvBadge();
}

function removePropRow(id) {
  document.getElementById(`prop-row-${id}`)?.remove();
  rebuildUrl();
  updateAdvBadge();
}

function updateAdvBadge() {
  const count = document.querySelectorAll('#extra-props-list .prop-row').length;
  document.getElementById('adv-count-badge').textContent = count;
}

function collectExtraProps() {
  const rows = document.querySelectorAll('#extra-props-list .prop-row');
  const result = [];
  rows.forEach(row => {
    const key   = row.querySelector('.prop-key').value.trim();
    const value = row.querySelector('.prop-value').value.trim();
    if (key && value) result.push({ key, value });
  });
  return result;
}

function buildConnPayload() {
  // Build exactly what the backend needs — all user-provided, nothing hardcoded
  return {
    db_type:      state.dbType,
    driver_class: v('conn-driver-class').trim(),
    jar_name:     v('conn-jar-name').trim(),
    jdbc_url:     v('conn-jdbc-url').trim(),
    username:     v('conn-username').trim(),
    password:     v('conn-password'),
    // Also pass individual fields so backend can fallback-build URL if needed
    host:         v('conn-host').trim(),
    port:         v('conn-port').trim(),
    database:     v('conn-database').trim(),
    extra_props:  collectExtraProps(),
  };
}

async function testConnection() {
  const payload   = buildConnPayload();
  const statusEl  = document.getElementById('conn-status');

  statusEl.className = 'conn-status loading';
  statusEl.innerHTML = '<span class="spinner"></span> Testing connection…';
  statusEl.classList.remove('hidden');

  try {
    const res  = await fetch(`${API}/api/validate-connection`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (res.ok) {
      if (data.mock) {
        statusEl.className = 'conn-status error';
        statusEl.innerHTML = `
          <div>
            <strong>⚠️ Running in DEMO MODE — not connected to a real database</strong><br>
            <small style="opacity:0.85;font-size:11px;font-family:var(--font-mono)">${esc(data.mock_reason || 'Unknown reason')}</small>
          </div>`;
      } else {
        statusEl.className = 'conn-status success';
        statusEl.innerHTML = '✅ Connected successfully to real database';
      }
      document.getElementById('btn-connect-next').disabled = false;
    } else {
      throw new Error(data.detail || 'Connection failed');
    }
  } catch (err) {
    statusEl.className = 'conn-status error';
    statusEl.innerHTML = `❌ ${esc(err.message)}`;
    document.getElementById('btn-connect-next').disabled = false;
  }
}

function renderSheetTableMapping() {
  const container = document.getElementById('sheet-table-mapping');
  container.innerHTML = state.sheets.map(s => `
    <div class="stm-row" id="stm-${esc(s.name)}">
      <span class="stm-sheet">📄 ${esc(s.name)}</span>
      <span class="stm-arrow">→</span>
      <input class="form-input" type="text" placeholder="target_table_name"
             id="table-input-${esc(s.name)}"
             value="${esc(state.sheetTableMap[s.name] || s.name.replace(/\s+/g,'_').toUpperCase())}" />
      <button class="stm-skip-btn ${state.skippedSheets.has(s.name) ? 'active' : ''}"
              onclick="toggleSkip('${esc(s.name)}', this)">
        ${state.skippedSheets.has(s.name) ? '↺ Un-skip' : '⊘ Skip'}
      </button>
    </div>`).join('');
}

function toggleSkip(sheetName, btn) {
  if (state.skippedSheets.has(sheetName)) {
    state.skippedSheets.delete(sheetName);
    btn.textContent = '⊘ Skip'; btn.classList.remove('active');
  } else {
    state.skippedSheets.add(sheetName);
    btn.textContent = '↺ Un-skip'; btn.classList.add('active');
  }
  fetch(`${API}/api/skip-table`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session_id: state.sessionId, sheet_name: sheetName, skip: state.skippedSheets.has(sheetName) }),
  });
}

async function fetchTableMetadata() {
  state.sheets.forEach(s => {
    const inp = document.getElementById(`table-input-${s.name}`);
    if (inp) state.sheetTableMap[s.name] = inp.value.trim() || s.name;
  });

  const tables = state.sheets
    .filter(s => !state.skippedSheets.has(s.name))
    .map(s => state.sheetTableMap[s.name]);

  const payload = buildConnPayload();
  state.connConfig = payload;

  try {
    const res  = await fetch(`${API}/api/fetch-table-metadata`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: state.sessionId, ...payload, tables }),
    });
    const data = await res.json();
    Object.entries(data.tables).forEach(([tbl, info]) => {
      state.dbTableMeta[tbl] = info.success ? info.columns : [];
    });
    return true;
  } catch (err) {
    showToast('error', `Fetch metadata failed: ${err.message}`);
    return false;
  }
}

// ═══════════════════════════════════════════════════════════════
//  STEP 3 — SCHEMA & MAPPING
// ═══════════════════════════════════════════════════════════════
async function buildSchemaMapping() {
  const tabs    = document.getElementById('tables-tabs');
  const content = document.getElementById('tables-content');
  tabs.innerHTML = ''; content.innerHTML = '';

  const activeSheets = state.sheets.filter(s => !state.skippedSheets.has(s.name));

  for (let i = 0; i < activeSheets.length; i++) {
    const sheet     = activeSheets[i];
    const tableName = state.sheetTableMap[sheet.name];
    const dbCols    = state.dbTableMeta[tableName] || [];

    const res = await fetch(`${API}/api/compare-schema`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: state.sessionId, sheet_name: sheet.name, table_name: tableName, db_columns: dbCols }),
    });
    const cmp = await res.json();
    state.schemaComparisons[sheet.name] = cmp;

    const initMapping = {};
    cmp.matched.forEach(m    => { initMapping[m.file_column] = m.db_column; });
    cmp.mismatched.forEach(m => { initMapping[m.file_column] = m.db_column; });
    Object.entries(cmp.suggestions).forEach(([fc, dc]) => { if (!initMapping[fc]) initMapping[fc] = dc; });
    state.columnMappings[sheet.name] = initMapping;

    const tabBtn = document.createElement('button');
    tabBtn.className = `tab-btn ${i === 0 ? 'active' : ''}`;
    tabBtn.textContent = sheet.name;
    tabBtn.dataset.sheet = sheet.name;
    tabBtn.addEventListener('click', () => switchTab(sheet.name));
    tabs.appendChild(tabBtn);

    const tabContent = document.createElement('div');
    tabContent.className = `tab-content ${i === 0 ? 'active' : ''}`;
    tabContent.id = `tab-${sheet.name}`;
    tabContent.innerHTML = buildTabHTML(sheet, tableName, cmp, dbCols);
    content.appendChild(tabContent);

    initMappingDropdowns(sheet.name, dbCols);
  }
}

function switchTab(sheetName) {
  document.querySelectorAll('.tab-btn').forEach(b     => b.classList.toggle('active', b.dataset.sheet === sheetName));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.toggle('active', c.id === `tab-${sheetName}`));
}

function buildTabHTML(sheet, tableName, cmp, dbCols) {
  const s = cmp.stats;
  return `
    <div class="skip-table-row">
      <label>
        <input type="checkbox" onchange="toggleSkipInMap('${esc(sheet.name)}', this)"
               ${state.skippedSheets.has(sheet.name) ? 'checked' : ''} />
        Skip this table (${esc(tableName)})
      </label>
      <div>
        <span class="badge badge-green">${s.matched} matched</span>
        ${s.mismatched  ? `<span class="badge badge-yellow" style="margin-left:4px">${s.mismatched} mismatch</span>`    : ''}
        ${s.missing_in_db ? `<span class="badge badge-red" style="margin-left:4px">${s.missing_in_db} missing</span>` : ''}
      </div>
    </div>
    ${renderSchemaSection('✅ Matched Columns',      cmp.matched,         'matched')}
    ${renderSchemaSection('⚠️ Type Mismatches',     cmp.mismatched,      'mismatched')}
    ${renderSchemaSection('➕ In File, Not in DB',   cmp.missing_in_db,   'missing_in_db')}
    ${renderSchemaSection('➖ In DB, Not in File',   cmp.missing_in_file, 'missing_in_file')}
    <div class="mapping-section">
      <h3>Column Mapping — <span class="mono" style="color:var(--accent)">${esc(sheet.name)}</span>
          → <span class="mono" style="color:var(--accent)">${esc(tableName)}</span></h3>
      <table class="mapping-table">
        <thead><tr><th>File Column</th><th>File Type</th><th>→ DB Column</th><th>DB Type</th></tr></thead>
        <tbody>
          ${sheet.columns.map(col => {
            const suggested = cmp.suggestions[col.name];
            const dbCol     = state.columnMappings[sheet.name][col.name] || '';
            return `<tr>
              <td>${esc(col.name)}${suggested && suggested !== col.name ? '<span class="suggested-badge">auto</span>' : ''}</td>
              <td><span class="tag-match mono">${esc(col.inferred_type)}</span></td>
              <td>
                <select class="form-select col-map-select"
                        data-sheet="${esc(sheet.name)}" data-file-col="${esc(col.name)}"
                        id="map-${esc(sheet.name)}-${esc(col.name)}">
                  <option value="">— skip —</option>
                  ${dbCols.map(dc => `<option value="${esc(dc.name)}" ${dbCol === dc.name ? 'selected' : ''}>${esc(dc.name)}</option>`).join('')}
                </select>
              </td>
              <td id="dbtype-${esc(sheet.name)}-${esc(col.name)}" class="mono tag-match">
                ${dbCol ? (dbCols.find(d => d.name === dbCol)?.data_type || '') : ''}
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
}

function renderSchemaSection(title, rows, type) {
  if (!rows?.length) return '';
  const cc = { matched:'tag-match', mismatched:'tag-mismatch', missing_in_db:'tag-missing', missing_in_file:'tag-extra' }[type];
  let hdr, cells;
  if (type === 'matched') {
    hdr   = '<th>File Column</th><th>DB Column</th><th>Type</th>';
    cells = rows.map(r => `<tr><td class="${cc}">${esc(r.file_column)}</td><td>${esc(r.db_column)}</td><td>${esc(r.file_type)}</td></tr>`).join('');
  } else if (type === 'mismatched') {
    hdr   = '<th>File Column</th><th>DB Column</th><th>File Type</th><th>DB Type</th>';
    cells = rows.map(r => `<tr><td class="${cc}">${esc(r.file_column)}</td><td>${esc(r.db_column)}</td><td>${esc(r.file_type)}</td><td class="tag-mismatch">${esc(r.db_type)}</td></tr>`).join('');
  } else if (type === 'missing_in_db') {
    hdr   = '<th>File Column</th><th>File Type</th>';
    cells = rows.map(r => `<tr><td class="${cc}">${esc(r.file_column)}</td><td>${esc(r.file_type)}</td></tr>`).join('');
  } else {
    hdr   = '<th>DB Column</th><th>DB Type</th>';
    cells = rows.map(r => `<tr><td class="${cc}">${esc(r.db_column)}</td><td>${esc(r.db_type)}</td></tr>`).join('');
  }
  return `<div class="schema-section">
    <div class="schema-section-title">${title}</div>
    <table class="schema-table"><thead><tr>${hdr}</tr></thead><tbody>${cells}</tbody></table>
  </div>`;
}

function initMappingDropdowns(sheetName, dbCols) {
  document.querySelectorAll(`.col-map-select[data-sheet="${sheetName}"]`).forEach(sel => {
    sel.addEventListener('change', () => {
      const fc = sel.dataset.fileCol;
      if (sel.value) state.columnMappings[sheetName][fc] = sel.value;
      else           delete state.columnMappings[sheetName][fc];
      const tc = document.getElementById(`dbtype-${sheetName}-${fc}`);
      if (tc) tc.textContent = sel.value ? (dbCols.find(d => d.name === sel.value)?.data_type || '') : '';
    });
  });
}

function toggleSkipInMap(sheetName, cb) {
  cb.checked ? state.skippedSheets.add(sheetName) : state.skippedSheets.delete(sheetName);
  fetch(`${API}/api/skip-table`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session_id: state.sessionId, sheet_name: sheetName, skip: cb.checked }),
  });
}

async function saveMappings() {
  for (const [sheetName, mapping] of Object.entries(state.columnMappings)) {
    if (state.skippedSheets.has(sheetName)) continue;
    await fetch(`${API}/api/save-mapping`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: state.sessionId,
        sheet_name: sheetName,
        table_name: state.sheetTableMap[sheetName],
        mapping,
      }),
    });
  }
}

// ═══════════════════════════════════════════════════════════════
//  STEP 4 — LOAD
// ═══════════════════════════════════════════════════════════════
async function startJob() {
  const res  = await fetch(`${API}/api/start-job`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session_id: state.sessionId }),
  });
  const data = await res.json();
  state.jobId = data.job_id;
  startTimer();
  streamLogs(state.jobId);
}

function startTimer() {
  state.elapsedSec = 0;
  state.timerInterval = setInterval(() => {
    state.elapsedSec++;
    document.getElementById('stat-time').querySelector('.stat-val').textContent = `${state.elapsedSec}s`;
  }, 1000);
}

function streamLogs(jobId) {
  const logBody     = document.getElementById('log-body');
  const fillEl      = document.getElementById('progress-fill');
  const pctEl       = document.getElementById('progress-pct');
  const autoscrollCb = document.getElementById('log-autoscroll');

  const es = new EventSource(`${API}/api/stream-logs/${jobId}`);
  es.onmessage = e => {
    const d = JSON.parse(e.data);
    if (d.type === 'done') {
      es.close(); clearInterval(state.timerInterval);
      fillEl.style.width = '100%'; pctEl.textContent = '100%';
      document.getElementById('load-footer').style.display = 'flex';
      fetchJobStatus(jobId);
      return;
    }
    if (d.type === 'log') {
      appendLog(logBody, d);
      if (autoscrollCb.checked) logBody.scrollTop = logBody.scrollHeight;
    }
  };

  const poll = setInterval(async () => {
    const status = await fetch(`${API}/api/job-status/${jobId}`).then(r => r.json()).catch(() => null);
    if (!status) return;
    fillEl.style.width = `${status.progress || 0}%`;
    pctEl.textContent  = `${status.progress || 0}%`;
    updateStats(status);
    if (['complete','partial'].includes(status.status)) clearInterval(poll);
  }, 1000);
}

function appendLog(container, log) {
  const div = document.createElement('div');
  div.className = 'log-line';
  div.innerHTML = `<span class="log-ts">${esc(log.timestamp)}</span>
    <span class="log-level ${log.level}">${log.level}</span>
    <span class="log-msg">${esc(log.message)}</span>`;
  container.appendChild(div);
}

async function fetchJobStatus(jobId) {
  const s = await fetch(`${API}/api/job-status/${jobId}`).then(r => r.json()).catch(() => null);
  if (!s) return;
  updateStats(s);
  const sv = document.getElementById('stat-status').querySelector('.stat-val');
  if (s.status === 'complete') { sv.textContent = '✅ Done';    sv.style.color = 'var(--green)'; }
  else if (s.status === 'partial') { sv.textContent = '⚠️ Partial'; sv.style.color = 'var(--yellow)'; }
}

function updateStats(status) {
  const results   = status.results || [];
  const ok        = results.filter(r => r.status === 'success');
  const totalRows = ok.reduce((s, r) => s + (r.rows || 0), 0);
  document.getElementById('stat-tables').querySelector('.stat-val').textContent = `${ok.length}/${results.length}`;
  document.getElementById('stat-rows').querySelector('.stat-val').textContent   = totalRows.toLocaleString();
  if (status.status === 'running')
    document.getElementById('stat-status').querySelector('.stat-val').textContent = '⏳ Running';
}

// ═══════════════════════════════════════════════════════════════
//  NAVIGATION
// ═══════════════════════════════════════════════════════════════
function initNavigation() {
  document.getElementById('btn-upload-next').addEventListener('click', () => {
    goToStep(2); renderSheetTableMapping();
  });
  document.getElementById('btn-connect-back').addEventListener('click', () => goToStep(1));
  document.getElementById('btn-test-conn').addEventListener('click', testConnection);

  document.getElementById('btn-connect-next').addEventListener('click', async () => {
    const btn = document.getElementById('btn-connect-next');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Fetching…';
    const ok = await fetchTableMetadata();
    btn.disabled = false; btn.textContent = 'Fetch Metadata →';
    if (ok) { goToStep(3); await buildSchemaMapping(); }
  });

  document.getElementById('btn-map-back').addEventListener('click', () => goToStep(2));
  document.getElementById('btn-map-next').addEventListener('click', async () => {
    await saveMappings(); goToStep(4); await startJob();
  });

  document.getElementById('btn-clear-log').addEventListener('click', () => {
    document.getElementById('log-body').innerHTML = '';
  });

  document.getElementById('btn-restart').addEventListener('click', () => {
    Object.assign(state, {
      sessionId: null, filename: null, sheets: [], dbType: 'sqlserver', connConfig: {},
      sheetTableMap: {}, skippedSheets: new Set(), dbTableMeta: {},
      schemaComparisons: {}, columnMappings: {}, jobId: null,
    });
    clearInterval(state.timerInterval);
    document.getElementById('upload-preview').classList.add('hidden');
    document.getElementById('btn-upload-next').disabled = true;
    document.getElementById('file-input').value = '';
    document.getElementById('log-body').innerHTML = '';
    document.getElementById('progress-fill').style.width = '0%';
    document.getElementById('progress-pct').textContent = '0%';
    document.getElementById('load-footer').style.display = 'none';
    document.getElementById('conn-status').classList.add('hidden');
    document.getElementById('btn-connect-next').disabled = true;
    // Reset extra props
    document.getElementById('extra-props-list').innerHTML = '';
    propRowId = 0;
    goToStep(1);
    switchDB('sqlserver');
  });

  document.getElementById('btn-download-report').addEventListener('click', () => {
    if (state.jobId) window.open(`${API}/api/download-report/${state.jobId}`, '_blank');
  });
}

function goToStep(n) {
  document.querySelectorAll('.panel').forEach((p, i) => p.classList.toggle('active', i + 1 === n));
  document.querySelectorAll('.step').forEach((s, i) => {
    s.classList.remove('active', 'done');
    if (i + 1 === n) s.classList.add('active');
    else if (i + 1 < n) s.classList.add('done');
  });
}

// ═══════════════════════════════════════════════════════════════
//  UTILITIES
// ═══════════════════════════════════════════════════════════════
function v(id) { return document.getElementById(id)?.value || ''; }

function esc(str) {
  if (str == null) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function showToast(type, message) {
  const icons = { success:'✅', error:'❌', warn:'⚠️', info:'📡' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span>${esc(message)}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 4500);
}
