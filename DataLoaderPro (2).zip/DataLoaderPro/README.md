# ⬡ DataLoader Pro

Load Excel / CSV data into SQL Server, Oracle, or Teradata — with schema comparison,
column mapping, real-time logs, and a progress dashboard.

---

## 📁 Folder Layout

```
DataLoaderPro\
│
│  ── Python backend ──────────────────────────────────────
├── main.py                  FastAPI app + all REST/SSE endpoints
├── db_connector.py          JDBC connections (SQL Server, Oracle, Teradata)
├── file_processor.py        Excel multi-sheet + CSV parser (pandas)
├── schema_comparator.py     Column diff + auto-mapping (string similarity)
├── data_loader.py           Type casting + batched INSERT
├── log_manager.py           Thread-safe log store for SSE streaming
├── requirements.txt         Python dependencies
│
│  ── Frontend ────────────────────────────────────────────
├── index.html               Single-page 4-step wizard UI
├── static\
│   ├── css\style.css        Dark industrial theme
│   └── js\app.js            All frontend logic (vanilla JS)
│
│  ── JDBC drivers (you supply) ───────────────────────────
├── jdbc\
│   ├── mssql-jdbc.jar       SQL Server driver
│   ├── ojdbc8.jar           Oracle driver
│   └── terajdbc4.jar        Teradata driver
│
│  ── Startup ─────────────────────────────────────────────
├── run.bat                  Windows one-click launcher
└── README.md
```

---

## 🚀 Quick Start (Windows)

1. Install **Python 3.9+** from https://www.python.org/downloads/
   - ✅ Check **"Add Python to PATH"** during installation

2. Double-click **`run.bat`**

   The batch file will:
   - Verify Python is available
   - Install all Python packages automatically
   - Start the web server
   - Open **http://localhost:8000** in your browser

---

## 🔌 JDBC Drivers (for real databases)

Place JAR files inside the `jdbc\` folder:

| Database   | File              | Download from                              |
|------------|-------------------|--------------------------------------------|
| SQL Server | `mssql-jdbc.jar`  | https://aka.ms/downloadmssqljdbc           |
| Oracle     | `ojdbc8.jar`      | https://www.oracle.com/database/technologies/appdev/jdbc.html |
| Teradata   | `terajdbc4.jar`   | https://downloads.teradata.com             |

**Without JAR files** the app runs in **Demo Mode** — all DB operations use
mock metadata so you can test the full 4-step UI without a real database.

---

## 📋 How It Works

### Step 1 — Upload
Drop an `.xlsx` (single or multi-sheet) or `.csv` file.
The app shows each sheet name, row count, and detected column types.

### Step 2 — Connect
Choose **SQL Server**, **Oracle**, or **Teradata**.
Enter connection details, map each sheet to a target table name,
optionally skip tables, then click **Test Connection**.

### Step 3 — Schema & Mapping
For each sheet/table pair:
- **Schema comparison** shows matched, mismatched, and missing columns
- **Column mapping dropdowns** let you map file columns → DB columns
- Auto-suggestions are made using string-similarity matching
- You can override any mapping manually
- Skip individual tables with a checkbox

### Step 4 — Load
Click **Load** to start. You'll see:
- Animated progress bar
- Live stats (tables processed, rows inserted, elapsed time)
- Real-time log stream (Server-Sent Events)
- Download a full JSON execution report when complete

---

## 🛠 Manual Run (if batch file doesn't work)

```cmd
cd DataLoaderPro
pip install fastapi "uvicorn[standard]" python-multipart pandas openpyxl xlrd
python main.py
```

Then open http://localhost:8000

---

## 📡 API Endpoints

| Method | Endpoint                        | Purpose                        |
|--------|---------------------------------|--------------------------------|
| POST   | /api/upload                     | Upload file, get session_id    |
| POST   | /api/validate-connection        | Test DB connection             |
| POST   | /api/fetch-table-metadata       | Get DB column list per table   |
| POST   | /api/compare-schema             | Diff file vs DB columns        |
| POST   | /api/save-mapping               | Save column mapping            |
| POST   | /api/skip-table                 | Mark/unmark a sheet to skip    |
| POST   | /api/start-job                  | Trigger load job               |
| GET    | /api/job-status/{job_id}        | Poll progress + results        |
| GET    | /api/stream-logs/{job_id}       | SSE real-time log stream       |
| GET    | /api/download-report/{job_id}   | Download JSON report           |

---

## ⚙️ Requirements

- Python 3.9 or higher
- Windows 10 / 11 (batch file), or any OS (run `python main.py` directly)
- Internet access on first run (to download Python packages)
- JDBC JARs only needed for real database connections
