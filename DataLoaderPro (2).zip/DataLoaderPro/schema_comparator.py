"""
Compares Excel/CSV columns with DB table columns.
Provides auto-mapping suggestions using string similarity.
"""

from difflib import SequenceMatcher
from typing import List, Dict, Any


class SchemaComparator:
    """Compare source (file) columns with target (DB) columns."""

    SIMILARITY_THRESHOLD = 0.6

    def compare(
        self,
        file_columns: List[Dict[str, str]],
        db_columns: List[Dict[str, str]],
    ) -> Dict[str, Any]:
        """
        Returns:
          matched    – columns that exist in both with compatible types
          mismatched – columns that exist in both but types differ
          missing_in_db – file columns not found in DB
          missing_in_file – DB columns not found in file
          suggestions – auto-mapping {file_col: db_col}
        """
        file_names = {c["name"].upper(): c for c in file_columns}
        db_names = {c["name"].upper(): c for c in db_columns}

        matched = []
        mismatched = []
        missing_in_db = []
        missing_in_file = []

        for fname, fmeta in file_names.items():
            if fname in db_names:
                dbmeta = db_names[fname]
                if self._types_compatible(fmeta.get("inferred_type", "VARCHAR"), dbmeta.get("data_type", "VARCHAR")):
                    matched.append({
                        "file_column": fmeta["name"],
                        "db_column": dbmeta["name"],
                        "file_type": fmeta.get("inferred_type"),
                        "db_type": dbmeta.get("data_type"),
                    })
                else:
                    mismatched.append({
                        "file_column": fmeta["name"],
                        "db_column": dbmeta["name"],
                        "file_type": fmeta.get("inferred_type"),
                        "db_type": dbmeta.get("data_type"),
                    })
            else:
                missing_in_db.append({
                    "file_column": fmeta["name"],
                    "file_type": fmeta.get("inferred_type"),
                })

        for dname, dmeta in db_names.items():
            if dname not in file_names:
                missing_in_file.append({
                    "db_column": dmeta["name"],
                    "db_type": dmeta.get("data_type"),
                })

        suggestions = self._auto_suggest(
            [c["name"] for c in file_columns],
            [c["name"] for c in db_columns],
        )

        return {
            "matched": matched,
            "mismatched": mismatched,
            "missing_in_db": missing_in_db,
            "missing_in_file": missing_in_file,
            "suggestions": suggestions,
            "stats": {
                "matched": len(matched),
                "mismatched": len(mismatched),
                "missing_in_db": len(missing_in_db),
                "missing_in_file": len(missing_in_file),
            },
        }

    def _auto_suggest(self, file_cols: List[str], db_cols: List[str]) -> Dict[str, str]:
        """Suggest best DB column for each file column using string similarity."""
        suggestions = {}
        db_upper = {c.upper(): c for c in db_cols}

        for fc in file_cols:
            fc_upper = fc.upper()
            if fc_upper in db_upper:
                suggestions[fc] = db_upper[fc_upper]
                continue

            best_match = None
            best_score = 0.0
            for dc_upper, dc_orig in db_upper.items():
                score = SequenceMatcher(None, fc_upper, dc_upper).ratio()
                if score > best_score:
                    best_score = score
                    best_match = dc_orig

            if best_score >= self.SIMILARITY_THRESHOLD and best_match:
                suggestions[fc] = best_match

        return suggestions

    def _types_compatible(self, source_type: str, target_type: str) -> bool:
        """Loose type compatibility check."""
        s = (source_type or "").upper()
        t = (target_type or "").upper()

        if s == t:
            return True

        numeric = {"INTEGER", "INT", "BIGINT", "SMALLINT", "DECIMAL", "NUMERIC", "FLOAT", "REAL", "NUMBER"}
        text = {"VARCHAR", "CHAR", "NVARCHAR", "TEXT", "CLOB", "STRING", "NCHAR"}
        date = {"DATE", "DATETIME", "TIMESTAMP", "TIMESTAMP(6)"}

        for group in (numeric, text, date):
            if s in group and t in group:
                return True

        return False
