"""
Applies column mapping, casts data types, and loads data into DB tables.
"""

import asyncio
from typing import Dict, List, Any, Tuple

import pandas as pd

from db_connector import DBConnector
from log_manager import LogManager


class DataLoader:
    BATCH_SIZE = 500

    TYPE_CAST = {
        "INTEGER": lambda v: int(float(v)) if v and str(v).strip() not in ("", "nan", "None") else None,
        "INT": lambda v: int(float(v)) if v and str(v).strip() not in ("", "nan", "None") else None,
        "BIGINT": lambda v: int(float(v)) if v and str(v).strip() not in ("", "nan", "None") else None,
        "DECIMAL": lambda v: float(v) if v and str(v).strip() not in ("", "nan", "None") else None,
        "NUMERIC": lambda v: float(v) if v and str(v).strip() not in ("", "nan", "None") else None,
        "FLOAT": lambda v: float(v) if v and str(v).strip() not in ("", "nan", "None") else None,
        "DATE": lambda v: str(v)[:10] if v and str(v).strip() not in ("", "nan", "None") else None,
        "TIMESTAMP": lambda v: str(v) if v and str(v).strip() not in ("", "nan", "None") else None,
        "VARCHAR": lambda v: str(v) if v and str(v).strip() not in ("", "nan", "None") else None,
        "CHAR": lambda v: str(v) if v and str(v).strip() not in ("", "nan", "None") else None,
    }

    def __init__(self, connector: DBConnector, log_manager: LogManager, job_id: str):
        self.connector = connector
        self.log = log_manager
        self.job_id = job_id

    async def load_data(
        self,
        df: pd.DataFrame,
        table_name: str,
        column_mapping: Dict[str, str],  # {file_col: db_col}
    ) -> Tuple[bool, int, str]:
        """
        Apply mapping + load. Returns (success, rows_loaded, error_msg).
        """
        try:
            # Filter columns included in mapping
            valid_file_cols = [fc for fc in column_mapping if fc in df.columns]
            if not valid_file_cols:
                return False, 0, "No mapped columns found in file"

            df_mapped = df[valid_file_cols].copy()
            df_mapped.rename(columns=column_mapping, inplace=True)
            db_columns = list(df_mapped.columns)

            self.log.log(self.job_id, "INFO", f"   Mapped {len(db_columns)} columns")

            # Fetch DB types for casting
            db_meta = {m["name"].upper(): m["data_type"].upper()
                       for m in self.connector.get_table_metadata(table_name)}

            # Cast rows
            rows = []
            error_rows = 0
            for _, row in df_mapped.iterrows():
                cast_row = []
                for col in db_columns:
                    raw = row[col]
                    db_type = db_meta.get(col.upper(), "VARCHAR")
                    caster = self.TYPE_CAST.get(db_type, self.TYPE_CAST["VARCHAR"])
                    try:
                        cast_row.append(caster(raw))
                    except Exception:
                        cast_row.append(None)
                        error_rows += 1
                rows.append(cast_row)

            if error_rows:
                self.log.log(self.job_id, "WARN", f"   Cast errors on {error_rows} cell(s) → set to NULL")

            # Load in batches
            total_loaded = 0
            for i in range(0, len(rows), self.BATCH_SIZE):
                batch = rows[i: i + self.BATCH_SIZE]
                loaded = self.connector.execute_insert(table_name, db_columns, batch)
                total_loaded += loaded
                self.log.log(self.job_id, "INFO",
                             f"   Batch {i // self.BATCH_SIZE + 1}: {loaded} rows inserted")
                await asyncio.sleep(0)  # yield to event loop

            return True, total_loaded, ""

        except Exception as e:
            return False, 0, str(e)
